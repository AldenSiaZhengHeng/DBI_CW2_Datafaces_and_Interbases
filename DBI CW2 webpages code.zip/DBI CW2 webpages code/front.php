<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Home Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="decoration.css" type="text/css">
		<link href="footer.css" rel="stylesheet" type="text/css" >
    </head>
	<style>
	.desc1{
		padding: 30px;
		text-align: center;
		background: #1abc9c;
		color: white;
		font-size: 30px;
		width: 96%;
		margin: auto;
		}
		
	.center {
		display: block;
		margin-left: auto;
		margin-right: auto;
		width: 50%;
		}
		
	.img1{
		background: url(1.jpg);
		background-repeat: no-repeat;
		background-size: auto;
		padding: 30px;
		text-align: center;
		margin-left:0;
		margin-right:0;
		color: white;
		font-size: 30px;
		font-style:italic;
	}
	
	.img2{
		background: url(2.jpg);
		background-repeat: no-repeat;
		background-size: auto;
		padding: 30px;
		text-align: auto;
		margin-left:0;
		margin-right:0;
		color: white;
		font-size: 20px;

	}
	
	.img3{
		background: url(3.jpg);
		background-repeat: no-repeat;
		background-size: 100%;
		padding: 30px;
		text-align: auto;
		color: black;
		font-size: 20px;
		margin-left:0;
		margin-right:0;

	}
	.footer{
	background: black;
	color: #d3d3d3;
	height: 150px;
	margin: auto;
	}

	a:link{
	color: #d3d3d3;
	text-decoration: none;
	}

	.copyright{
		margin-right: 40px;
		text-align:right;
		margin-right:40px;
	}

	.contact2{
	margin-left: 40px;
	}

	.contact1{
	text-align:right;
	margin-right:40px;
	margin-top:-120px;
	}
	
	.footer_title{
		text-align:left;
		margin-left: 40px;
	}

	.search_actor{
		background-color: #4CAF50;
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
		border-radius: 10px;
		margin-left:80%;
	}
	.search_category{
		background-color: #4CAF50;
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
		border-radius: 10px;
		margin-left:80%;
	}
	
	</style>
    <body>

        <div class="header">
            <h1>Datafaces and Interbases</h1>
            <div class="dropdown">
            <button class="dropbtn">Show all data</button>
                <div class="dropdown-content">
                    <a href="actor.php">Actor</a>
                    <a href="address.php">Address</a>
                    <a href="category.php">Category</a>
                    <a href="city.php">City</a>
                    <a href="country.php">Country</a>
                    <a href="customer.php">Customer</a>
                    <a href="film.php">Film</a>
                    <a href="film_actor.php">Film Actor</a>
                     <a href="film_category.php">Film Category</a>
                    <a href="inventory.php">Inventory</a>
                    <a href="language.php">Language</a>
                    <a href="payment.php">Payment</a>
                    <a href="rental.php">Rental</a>
                    <a href="staff.php">Staff</a>
                    <a href="store.php">Store</a>
                </div>
            </div>
            <div class="dropdown">
            <button class="dropbtn">Edit data</button>
                <div class="dropdown-content">
                    <a href="actor_edit.php">Actor edit</a>
                    <a href="address_edit.php">Address edit</a>
                    <a href="category_edit.php">Category edit</a>
                    <a href="city_edit.php">City edit</a>
                    <a href="country_edit.php">Country edit</a>
                    <a href="customer_edit.php">Customer edit</a>
                    <a href="film_edit.php">Film edit</a>
                    <a href="film_actor_edit.php">Film Actor edit</a>
                    <a href="film_category_edit.php">Film Category edit</a>
                    <a href="inventory_edit.php">Inventory edit</a>
                    <a href="language_edit.php">Language edit</a>
                    <a href="payment_edit.php">Payment edit</a>
                    <a href="rental_edit.php">Rental edit</a>
                    <a href="staff_edit.php">Staff edit</a>
                    <a href="store_edit.php">Store edit</a>
                </div>
            </div>
        </div>
		
		
		<div class="img1">
		<p><br />
		<br />
		<br />
		<br />
		<br />
		<br /></p>
		<p>THIS database allow user to do <strong>SELECT, INSERT, DELETE, UPDATE</strong> through web interfaces.</p>
		<p><br />
		<br />
		<br />
		<br />
		<br />
		<br /></p>
		</div>
		
		
		
		<div class = "img2">
		<h2>Search for favourite actor</h2>
		<br />
		<br />
		<p>This section is helping you to find your favourtie actor that have stareed in the film</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;You can find them by searching through your favourite actor firstname</p>
			<div>
			<button class="search_actor" onclick="document.location='search_actor.php'">Search actor</button>
			</div>
		<br>
		<br>
		<br>
			</div>
			
		<div class = "img3">
		<br>
		<br>
		<br>
		<h2>Search for film category</h2>
		<p>This section will help you to find your favourite category of each file which can save your time for finding them.</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;You can find them by searching through your favourite category</p>
			<div>
			<button class="search_category" onclick="document.location='search_category.php'">Search film category</button>
			</div>
		<br>
		<br>
		<br>
		</div>

		<div class="footer">
		<br>
		<h2 class="footer_title">Contact Us</h2>
		<script src="https://kit.fontawesome.com/59c406b998.js" crossorigin="anonymous"></script>
		<div class="footer-content">
			
		</div>
	
		<div class="footer-section contact">
			<p class="contact2">
				<i class="fas fa-phone"></i>
				Phone Number:
				<a href="tel:999" >999</a>
			</p>
			
			<p class="contact2">
				<i class="fas fa-envelope"></i>
				E-mail:
				<a href="mailto:ows4207@gmail.com">ows4207@gmail.com</a>
			</p>
		</div>
		<div class="contact1">
			<p>Designed by Datafaces and Interbases Team<br>
		</div>
		<div class="copyright">
			<p >&copy; http://hfyas6.mercury.nottingham.edu.my/front.php </p>
		</div>
	</div>	
    </body>
</html>

<?php
    require "server.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="decoration.css" type="text/css">
    <style>
      table, th ,td {
          border: 1px solid black;
      }

      #myInput {
        background-image: url('/css/searchicon.png');
        background-position: 10px 10px;
        background-repeat: no-repeat;
        width: 96%;
        font-size: 16px;
        padding: 12px 20px 12px 40px;
        border: 1px solid #ddd;
        margin-bottom: 12px;
      }

      #myTable {
        border-collapse: collapse;
        margin:25px 0;
        width: 100%;
        border: 1px solid #ddd;
        font-size: 18px;
        font-family: sans-serif;
        min-width: 400px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
      }

      #myTable th, #myTable td {
        text-align: left;
        padding: 12px;
      }

      #myTable tr {
        border-bottom: 1px solid #ddd;
      }

      #myTable tr.head, #myTable tr:hover {
        background-color: #f1f1f1;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <h1>Datafaces and Interbases</h1>
      <div class="dropdown">
        <button class="dropbtn" onclick="document.location.href='front.php'" >HOME</button>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Show all data</button>
            <div class="dropdown-content">
                <a href="actor.php">Actor</a>
                <a href="address.php">Address</a>
                <a href="category.php">Category</a>
                <a href="city.php">City</a>
                <a href="country.php">Country</a>
                <a href="customer.php">Customer</a>
                <a href="film.php">Film</a>
                <a href="film_actor.php">Film Actor</a>
                <a href="film_category.php">Film Category</a>
                <a href="inventory.php">Inventory</a>
                <a href="language.php">Language</a>
                <a href="payment.php">Payment</a>
                <a href="rental.php">Rental</a>
                <a href="staff.php">Staff</a>
                <a href="store.php">Store</a>
            </div>
        </div>
        <div class="dropdown">
        <button class="dropbtn">Edit data</button>
            <div class="dropdown-content">
                  <a href="actor_edit.php">Actor edit</a>
                <a href="address_edit.php">Address edit</a>
                <a href="category_edit.php">Category edit</a>
                <a href="city_edit.php">City edit</a>
                <a href="country_edit.php">Country edit</a>
                <a href="customer_edit.php">Customer edit</a>
                <a href="film_edit.php">Film edit</a>
                <a href="film_actor_edit.php">Film Actor edit</a>
                <a href="film_category_edit.php">Film Category edit</a>
                <a href="inventory_edit.php">Inventory edit</a>
                <a href="language_edit.php">Language edit</a>
                <a href="payment_edit.php">Payment edit</a>
                <a href="rental_edit.php">Rental edit</a>
                <a href="staff_edit.php">Staff edit</a>
                <a href="store_edit.php">Store edit</a>
            </div>
      </div>
    </div>

    <h1 style="text-align:center">Search For Your Favourite Actor</h1>
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Actor Firstname.." title="Type in a name">

    <table id="myTable">
      <tr class="head">
        <th style="width:20%;">Film ID</th>
        <th style="width:30%;">Title</th>
        <th style="width:30%;">Actor Firstname</th>
        <th style="width:30%;">Actor Lastname</th>
      </tr>
      <?php
        $sql = "SELECT * FROM film_actor INNER JOIN film ON film.film_id = film_actor.film_id
                INNER JOIN actor ON actor.actor_id = film_actor.actor_id
                ORDER BY film.film_id";
        $result = mysqli_query($conn,$sql);
        

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()){
                echo '<tr><td>'. $row["film_id"] . '</td><td>'. $row["title"]. '</td><td>'. $row["first_name"]. '</td><td>'.$row["last_name"].'</td></tr>';
            }
        }
        else{
            echo "0 results";
        }

        ?>
    </table>

    <script>
    function myFunction() {
      var input, filter, table, tr, td, i, txtValue;
      input = document.getElementById("myInput");
      filter = input.value.toUpperCase();
      table = document.getElementById("myTable");
      tr = table.getElementsByTagName("tr");
      for (i = 0; i < tr.length; i++) {
          //Obtain the column for the input
        td = tr[i].getElementsByTagName("td")[2];
        if (td) {
          txtValue = td.textContent || td.innerText;
          if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
          } else {
            tr[i].style.display = "none";
          }
        }       
      }
    }
  </script>

  </body>
</html>

<?php
  require "server.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="decoration.css" type="text/css">
  <style>
    h1{
      padding: 25px;
      text-align: center;
      color: black;
      font-size: 59px;
    }

    .col-lg-4 {
      margin: auto;
      width: 100%;
    }

    body{
      /* The image used */
      background-image: url("3.jpg");
      /* Full height */
      height: 100%;
      max-width: 100%;
      position:relative;

      /* Center and scale the image nicely */
      background-repeat: repeat;
      background-size: cover;
    }

    .head {
      padding: 60px;
      text-align: center;
      font-size: 30px;
      font-style:italic;
    }

    .dropbtn{
      background-color:burlywood;
    }
</style>
</head>
<body>
<div class="head">
    <h1>Datafaces and Interbases</h1>
    <div class="dropdown">
      <button class="dropbtn" onclick="document.location.href='front.php'" >HOME</button>
    </div>
    <div class="dropdown">
        <button class="dropbtn">Show all data</button>
            <div class="dropdown-content">
                <a href="actor.php">Actor</a>
                <a href="address.php">Address</a>
                <a href="category.php">Category</a>
                <a href="city.php">City</a>
                <a href="country.php">Country</a>
                <a href="customer.php">Customer</a>
                <a href="film.php">Film</a>
                <a href="film_actor.php">Film Actor</a>
                <a href="film_category.php">Film Category</a>
                <a href="inventory.php">Inventory</a>
                <a href="language.php">Language</a>
                <a href="payment.php">Payment</a>
                <a href="rental.php">Rental</a>
                <a href="staff.php">Staff</a>
                <a href="store.php">Store</a>
            </div>
        </div>
        <div class="dropdown">
        <button class="dropbtn">Edit data</button>
            <div class="dropdown-content">
                  <a href="actor_edit.php">Actor edit</a>
                <a href="address_edit.php">Address edit</a>
                <a href="category_edit.php">Category edit</a>
                <a href="city_edit.php">City edit</a>
                <a href="country_edit.php">Country edit</a>
                <a href="customer_edit.php">Customer edit</a>
                <a href="film_edit.php">Film edit</a>
                <a href="film_actor_edit.php">Film Actor edit</a>
                <a href="film_category_edit.php">Film Category edit</a>
                <a href="inventory_edit.php">Inventory edit</a>
                <a href="language_edit.php">Language edit</a>
                <a href="payment_edit.php">Payment edit</a>
                <a href="rental_edit.php">Rental edit</a>
                <a href="staff_edit.php">Staff edit</a>
                <a href="store_edit.php">Store edit</a>
            </div>
      </div>
  </div>
<div class="container">
<div class="col-lg-4">
  <h2 style="text-align:center">Edit Inventory Table</h2>
  <!--Modify this part-->
  <!--change label for, input type, id and name-->
  <form action="" name ="form1" method="post">
    <div class="form-group">
      <label for="inventory_id">Inventory ID:</label>
      <input type="text" class="form-control" id="inventory_id" placeholder="Enter inventory ID" name="inventory_id" required>
    </div>
    <div class="form-group">
      <label for="film_id">Film ID:</label>
      <input type="text" class="form-control" id="film_id" placeholder="Enter film ID" name="film_id" required>
    </div>
    <div class="form-group">
      <label for="store_id">Store ID:</label>
      <input type="text" class="form-control" id="store_id" placeholder="Enter store ID" name="store_id" required>
    </div>

    <!--until above-->
    <button type="submit" name="insert" class="btn btn-default">Insert</button>
    <button type="submit" name="update" class="btn btn-default">Update</button>
    <button type="submit" name="delete" class="btn btn-default">Delete</button>
    
  </form>
</div>
</div>

<br />
</body>

<?php
// Modify the assign value
if(isset($_POST["insert"])){
    $inventory_id = $_POST['inventory_id'];
    $film_id = $_POST['film_id'];
    $store_id = $_POST['store_id'];
    date_default_timezone_set('Asia/Singapore');  
    $last_update = date('Y-m-d H:i:s');
    //$last_update = $_POST['last_update'];

    $query = "insert into inventory(inventory_id,film_id,store_id,last_update) values ('$inventory_id','$film_id','$store_id','$last_update')";
    $run = mysqli_query($conn,$query);
  
    if($run){
        echo "<script> alert('Your values have been INSERTED successfully!');window.location='inventory.php' </script>";
        //echo "Form submitted succesfully";
      }
      else{
        echo "<script> alert('The INSERTION has FAILED! Please try to insert again');window.location='inventory_edit.php' </script>";
      }
  }
  if(isset($_POST["delete"])){
    $inventory_id = $_POST['inventory_id'];
    $film_id = $_POST['film_id'];
    $store_id = $_POST['store_id'];
    date_default_timezone_set('Asia/Singapore');  
    $last_update = date('Y-m-d H:i:s');
    $query = "delete from inventory where inventory_id = '$inventory_id'";
    $run = mysqli_query($conn,$query);

    if($run){
      echo "<script> alert('Your selected row had been DELETE successfully!');window.location='inventory.php' </script>";
    }
    else{
      echo "<script> alert('Your selected row is NOT DELETE successfully!');window.location='inventory_edit.php' </script>";
    }
  }
  if(isset($_POST["update"])){
    $inventory_id = $_POST['inventory_id'];
    $film_id = $_POST['film_id'];
    $store_id = $_POST['store_id'];
    date_default_timezone_set('Asia/Singapore');  
    $last_update = date('Y-m-d H:i:s');
    $query = "update inventory set inventory_id = '$inventory_id', film_id = '$film_id', store_id = '$store_id',last_update = '$last_update' where inventory_id = '$inventory_id'";
    $run = mysqli_query($conn,$query);

    if($run){
      echo "<script> alert('Your form has been updated successfully!');window.location='inventory.php' </script>";
    }
    else{
      echo "<script> alert('Your form has NOT updated successfully!');window.location='inventory_edit.php' </script>";
  }
  }
?>
</html>

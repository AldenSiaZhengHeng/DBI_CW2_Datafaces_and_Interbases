<?php
    $servername = "localhost";
    $username = "hfyas6me_hfyas6";
    $password = "hfyas6@nottingham.edu.my";
    $dbname = "hfyas6me_entertainment";


    $conn =  mysqli_connect($servername, $username, $password, $dbname);
    
    //check connection
    if($conn->connect_error){
        die("Connection failed: ". $conn->connect_error);
    }
    //echo "<h1>Connection successfully</h1>";


    ?>